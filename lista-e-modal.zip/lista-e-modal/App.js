import * as React from 'react';
import { Text, View, StyleSheet, FlatList, Pressable, Image,Modal } from 'react-native';
import Constants from 'expo-constants';


const ShowDetalhes = ({display,toogleModal,mensagem}) => (   
    <Modal
          animationType="fade"
          transparent={true}
          visible={display}
          onRequestClose={toogleModal}
    >

        <View style={styles.centeredView}>
          <View style={styles.modalView}>
                <Pressable onPress={toogleModal}>
                  <Text>{mensagem}</Text>
                </Pressable>
          </View>
        </View>
    
    </Modal>
        
 )

const Prato = ({prato,valor,link}) => {
    
    //state para controle do Modal
    const [modal,setModal] = React.useState(false)

    function mudaModal(){
      setModal(!modal)
    }

    return(
    <View>
      <ShowDetalhes display={modal} toogleModal={mudaModal} mensagem={prato +": "+valor}/>
      
      <Pressable onPress={mudaModal}>
        <Image
          style={styles.tinyLogo}
          source={{
            uri: link,
          }}
        />

        <Text style={styles.paragraph}>{prato}</Text>
      </Pressable>
    </View>
    )
}


const DATA = [
        {
            "id": 7,
            "valor": "R$40,00",
            "prato": "Macarronada",
            "foto":  "https://images.pexels.com/photos/1256875/pexels-photo-1256875.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260"
        },
        {
            "id": 8,
            "valor": "R$50,00",
            "prato": "Frango à Parmegiana",
            "foto": "https://media.istockphoto.com/photos/parmegiana-fillet-picture-id506672136?s=612x612"
        },
        {
            "id": 9,
            "valor": "R$80,00",
            "prato": "Moqueca Baiana",
            "foto": "https://media.istockphoto.com/photos/brazilian-cuisine-shrimp-stew-usually-served-with-rice-mush-and-picture-id1252504256?s=612x612"
        },
        {
            "id": 10,
            "valor": "R$20,00",
            "prato": "Hamburger",
            "foto": "https://images.pexels.com/photos/2702674/pexels-photo-2702674.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
        },
        {
            "id": 11,
            "valor": "R$20,00",
            "prato": "Frango Frito",
            "foto": "https://images.pexels.com/photos/60616/fried-chicken-chicken-fried-crunchy-60616.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
        },
        {
            "id": 12,
            "valor": "R$35,00",
            "prato": "Yakisoba",
            "foto": "https://media.istockphoto.com/photos/chinese-noodles-with-sliced-beefs-with-fresh-vegetables-served-on-a-picture-id1031384082?s=612x612"
        }
    ];



//item com uma arrow function
/*const meuItemObj = ({item}) => (
  <View>
      <Text style={styles.paragraph}>{item.title}</Text>
    </View>
)*/



export default function App() {

  //função que renderiza cada item do FlatList
  function meuItem({item}){
    let nomePrato = item.prato
    
    return(
      <Prato prato={nomePrato} 
              link={item.foto}
              valor={item.valor}
      />
    )
  }
  

  return (

    <View style={styles.container}>

      <FlatList
        data={DATA}
        renderItem={meuItem}
        keyExtractor={item => item.id}
      />
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 12,
    padding: 12,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: 'lightgreen'
  },
  tinyLogo: {
    width: 50,
    height: 50,
    alignSelf: 'center'
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
